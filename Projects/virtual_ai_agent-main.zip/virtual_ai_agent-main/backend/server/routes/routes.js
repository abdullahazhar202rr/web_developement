import { Router } from "express";
import { processCommand } from "../controllers/controllers.js";
const router = Router();

router.post("/command", processCommand);

export default router;
