import express from "express";
import dotenv from "dotenv";
import router from "./server/routes/routes.js";
import cors from "cors";

// DOtenv COnfig
dotenv.config();

// Rest Object
const app = express();

// Middleware
app.use(express.json());

// cors
app.use(
  cors({
    origin: "*",
    credentials: true,
  })
);

// Rest API
app.get("/", (req, res) => {
  res.status(200).send({
    success: true,
    message: "The server is running",
  });
});

// BAse URl
app.use("/api", router);

const PORT = process.env.PORT;
const NODE_ENV = process.env.NODE_ENV;

app.listen(PORT, () => {
  console.log(`The server is running on port : ${PORT} in ${NODE_ENV} mode`);
});
