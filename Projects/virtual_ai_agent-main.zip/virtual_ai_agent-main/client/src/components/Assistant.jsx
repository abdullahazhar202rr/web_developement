import React, { useState, useEffect } from "react";
import { Mic, MicOff, Volume2, Brain, Waves } from "lucide-react";

const Assistant = () => {
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [response, setResponse] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);

  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

  // Get available voices
  const [voices, setVoices] = useState([]);

  useEffect(() => {
    const loadVoices = () => {
      const allVoices = window.speechSynthesis.getVoices();
      setVoices(allVoices);
    };

    // Load immediately or after voices change
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }, []);

  const startListening = () => {
    if (!SpeechRecognition) {
      alert("Speech Recognition not supported in this browser.");
      return;
    }

    const recog = new SpeechRecognition();
    recog.continuous = false;
    recog.lang = "en-US";
    recog.interimResults = false;

    recog.onstart = () => setListening(true);

    recog.onresult = async (event) => {
      const text = event.results[0][0].transcript;
      console.log("🎙️ You said:", text);
      setTranscript(text);
      await sendToBackend(text);
      setListening(false);
    };

    recog.onerror = (err) => {
      console.error("❌ Speech recognition error:", err);
      setListening(false);
    };

    recog.onend = () => setListening(false);
    recog.start();
  };

  const speakResponse = (text) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "en-US";
    utterance.pitch = 1.2;
    utterance.rate = 1;
    utterance.volume = 1;

    // Try to pick a smart-sounding voice (optional)
    const jarvisVoice = voices.find(
      (v) =>
        v.name.toLowerCase().includes("english") &&
        v.name.toLowerCase().includes("male")
    );
    if (jarvisVoice) {
      utterance.voice = jarvisVoice;
    }

    window.speechSynthesis.speak(utterance);
  };

  const sendToBackend = async (text) => {
    setIsProcessing(true);
    try {
      const res = await fetch("http://localhost:3000/api/command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });

      const data = await res.json();
      const reply = data.response || "No response received.";
      console.log("🤖 Jarvis replied:", reply);
      setResponse(reply);
      speakResponse(reply);
    } catch (err) {
      console.error("❌ Backend error:", err);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-20 w-72 h-72 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-20 left-1/2 w-72 h-72 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse delay-2000"></div>
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 mb-4">
            <Brain className="w-10 h-10 text-cyan-400" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
              G.U.R.Y.A
            </h1>
          </div>
          <p className="text-xl text-slate-300 font-light">
            Just A Rather Very Intelligent System
          </p>
        </div>

        {/* Main interaction area */}
        <div className="relative">
          {/* Circular visualization */}
          <div className="relative w-48 h-48 mb-8 mx-auto">
            <div
              className={`absolute inset-0 rounded-full border-2 border-cyan-400/30 ${
                listening ? "animate-ping" : ""
              }`}
            ></div>
            <div
              className={`absolute inset-4 rounded-full border-2 border-blue-400/50 ${
                listening ? "animate-ping delay-75" : ""
              }`}
            ></div>
            <div
              className={`absolute inset-8 rounded-full border-2 border-purple-400/70 ${
                listening ? "animate-ping delay-150" : ""
              }`}
            ></div>

            {/* Center button */}
            <button
              onClick={startListening}
              disabled={isProcessing}
              className={`absolute inset-12 rounded-full flex items-center justify-center text-white font-medium transition-all duration-300 transform hover:scale-105 ${
                listening
                  ? "bg-gradient-to-r from-red-500 to-pink-500 shadow-lg shadow-red-500/50"
                  : isProcessing
                  ? "bg-gradient-to-r from-yellow-500 to-orange-500 shadow-lg shadow-yellow-500/50"
                  : "bg-gradient-to-r from-cyan-500 to-blue-500 shadow-lg shadow-cyan-500/50 hover:shadow-cyan-500/70"
              }`}
            >
              {listening ? (
                <MicOff className="w-8 h-8" />
              ) : isProcessing ? (
                <Waves className="w-8 h-8 animate-bounce" />
              ) : (
                <Mic className="w-8 h-8" />
              )}
            </button>
          </div>

          {/* Status text */}
          <div className="text-center mb-8">
            <p className="text-lg font-medium">
              {listening ? (
                <span className="text-red-400 flex items-center gap-2 justify-center">
                  <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse"></div>
                  Listening...
                </span>
              ) : isProcessing ? (
                <span className="text-yellow-400 flex items-center gap-2 justify-center">
                  <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                  Processing...
                </span>
              ) : (
                <span className="text-slate-400">
                  Click to activate voice command
                </span>
              )}
            </p>
          </div>
        </div>

        {/* Conversation display */}
        <div className="w-full max-w-4xl space-y-6">
          {/* User input */}
          {transcript && (
            <div className="bg-slate-800/60 backdrop-blur-sm border border-slate-700 rounded-2xl p-6 shadow-xl">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-cyan-400 to-blue-400 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-white">YOU</span>
                </div>
                <div className="flex-1">
                  <h3 className="text-cyan-400 font-medium mb-2">
                    Voice Command
                  </h3>
                  <p className="text-slate-100 text-lg leading-relaxed">
                    {transcript}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Assistant response */}
          {response && (
            <div className="bg-slate-800/60 backdrop-blur-sm border border-slate-700 rounded-2xl p-6 shadow-xl">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center flex-shrink-0">
                  <Brain className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-purple-400 font-medium">
                      G.U.R.Y.A. Response
                    </h3>
                    <Volume2 className="w-4 h-4 text-slate-400" />
                  </div>
                  <p className="text-slate-100 text-lg leading-relaxed">
                    {response}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Instructions */}
        {!transcript && !response && (
          <div className="mt-12 text-center">
            <p className="text-slate-400 text-sm max-w-md mx-auto leading-relaxed">
              Press the microphone button and speak your command. J.A.R.V.I.S
              will listen, process your request, and respond with both text and
              speech.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Assistant;
