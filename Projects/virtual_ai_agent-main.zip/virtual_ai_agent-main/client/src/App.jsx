import Assistant from "./components/Assistant";
const App = () => {
  return (
    <div className="App">
      <Assistant />
    </div>
  );
};

export default App;
